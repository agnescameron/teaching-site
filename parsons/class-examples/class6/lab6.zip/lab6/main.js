function changeHeading () {
	$('#heading').css({"background-color": "yellow"})
}