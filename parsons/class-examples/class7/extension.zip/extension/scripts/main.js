$(document).ready( function() {

  $( 'img' ).attr({"src":  chrome.extension.getURL("img/potato1.jpg"),
  "srcset": chrome.extension.getURL("img/potato1.jpg") })

})


